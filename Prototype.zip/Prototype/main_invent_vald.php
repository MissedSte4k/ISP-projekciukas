<?php
include("include/session.php");
?>
<!DOCTYPE html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8"/>
        <title>Lukiškių kalėjimas</title>
        <link href="css/style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
      <header id='main_header'>
        <div class="container">
          <h1>Inventoriaus valdymas</h1>
        </div>
      </header>
                <?php include("include/inventoryMeniu.php");
                ?>
                <div style="text-align: center;color:green">
                    <br><br><br><br><br><br><br><br><br><br><br><br><br>
                    <h1>Sveiki, atvykę į Lukiškių kalėjimo informacinę sistemą.</h1>
                </div><br><br><br><br><br><br><br>

              <?php  include("include/footer.php");?>
</body>
</html>
